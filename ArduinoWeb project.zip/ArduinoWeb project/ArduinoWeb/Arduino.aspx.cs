﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO.Ports;

namespace ArduinoWeb
{
    public partial class Arduino : System.Web.UI.Page
    {
        bool LedOn;
        string SerialAvailable;
        static SerialPort serialPort1 = new SerialPort();

        protected void Page_Load(object sender, EventArgs e)
        {

            Config();
            if (!IsPostBack)
            {
                apagasala.Enabled = false;
                apagaquarto.Enabled = false;
                apagacozinha.Enabled = false;
            }

        }

        public void Config()
        {
            serialPort1.Close();
            serialPort1.PortName = "COM5";
            serialPort1.BaudRate = 9600;
            serialPort1.Open();
            // Button2.Enabled = false;   apagar botões não ultilizados
            LedOn = false;

        }

        protected void acendesala_Click(object sender, EventArgs e)
        {
            LedOn = true;

            if (LedOn == true)
            {
                serialPort1.Write("v");
                acendesala.Enabled = false;
                apagasala.Enabled = true;
            }
        }

        protected void apagasala_Click(object sender, EventArgs e)
        {
            LedOn = false;

            if (LedOn == false)
            {
                serialPort1.Write("f");
                apagasala.Enabled = false;
                acendesala.Enabled = true;
            }
        }

        protected void acendecozinha_Click(object sender, EventArgs e)
        {

            LedOn = true;

            if (LedOn == true)
            {
                serialPort1.Write("0");
                acendecozinha.Enabled = false;
                apagacozinha.Enabled = true;
            }

        }

        protected void apagacozinha_Click(object sender, EventArgs e)
        {
            LedOn = false;

            if (LedOn == false)
            {
                serialPort1.Write("1");
                apagacozinha.Enabled = false;
                acendecozinha.Enabled = true;
            }
        }

       

        protected void acendequarto_Click(object sender, EventArgs e)
        {
            LedOn = true;

            if (LedOn == true)
            {
                serialPort1.Write("2");
                acendequarto.Enabled = false;
                apagaquarto.Enabled = true;
            }

        }

        protected void apagaquarto_Click(object sender, EventArgs e)
        {
            LedOn = false;

            if (LedOn == false)
            {
                serialPort1.Write("3");
                apagaquarto.Enabled = false;
                acendequarto.Enabled = true;
            }

        }

       

       

       
    }
}